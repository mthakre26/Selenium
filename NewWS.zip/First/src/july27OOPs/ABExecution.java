package july27OOPs;

public class ABExecution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*B b = new B();
		b.method2();
		b.method3();
		C c = new C();
	
		c.method2();
		c.method4();
		c.method1();
		c.method3();*/
		//C c = new C();
	//	B b = new B();
		C c = new C(200111);
		//c.method4();
	}

}
