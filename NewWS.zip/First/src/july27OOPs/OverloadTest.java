package july27OOPs;

public class OverloadTest {

	public void add(int a, int b){
		
	}

public void add(int a, float b){
	
}
public void add(float a,float b){
	System.out.println(a+b);
}
public void add(float a, int b){
	
}
public void add(int a, int b, int c){
	
}
	
}
