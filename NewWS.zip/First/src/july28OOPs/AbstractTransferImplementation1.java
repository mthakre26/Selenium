package july28OOPs;

public abstract class AbstractTransferImplementation1 extends AbstractTransferImplementation{

	@Override
	public void mobile() {
		// TODO Auto-generated method stub
		System.out.println("Account Transfer Mobile");
	}

}
