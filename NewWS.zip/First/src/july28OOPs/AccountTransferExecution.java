package july28OOPs;

public class AccountTransferExecution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		AccountTransferImplementation2 at = new AccountTransferImplementation2();
		at.mobile();
		at.Neft();
		
		at.add();
		at.saving();
		at.modify();
		
	}

}
