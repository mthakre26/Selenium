package july28OOPs;

public class AccountTransferImplementation2 extends AbstractTransferImplementation1 {

	@Override
	public void Imps() {
		// TODO Auto-generated method stub
		System.out.println("Account transfer IMPS");
	}

	@Override
	public void email() {
		// TODO Auto-generated method stub
		System.out.println("Account transfre email");
	}

	@Override
	public void add() {
		System.out.println("addition of Benfcry");
		
	}

	@Override
	public void modify() {
		// TODO Auto-generated method stub
		System.out.println("Modif of Benfcry");
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		System.out.println("Del of Benfcry");
	}

	@Override
	public void saving() {
		// TODO Auto-generated method stub
		System.out.println("Savings account");
	}

	
	
	
}
