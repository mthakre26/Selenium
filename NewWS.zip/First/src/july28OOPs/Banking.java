package july28OOPs;

public interface Banking  {

	
	public abstract void saving();
	
}
