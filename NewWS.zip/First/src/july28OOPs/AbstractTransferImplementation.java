package july28OOPs;

public abstract class AbstractTransferImplementation implements AccountTransfer   {

	@Override
	public void Neft() {
		// TODO Auto-generated method stub
		System.out.println("Account transfer implementation Neft");
	}

	@Override
	public void Upi() {
		// TODO Auto-generated method stub
		System.out.println("Account transfer through UPI");
	}

	
}
