package july28OOPs;

public class EncapsulationExExecution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EncapsulationEx ex = new EncapsulationEx();
		
		ex.setName("Pune");
		ex.setYear(2019);
		
		System.out.println(ex.getName());
		System.out.println(ex.getYear());
	}

}
