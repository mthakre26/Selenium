package july28OOPs;

public abstract class Abs {

}
