package Mind;
import java.util.Scanner;
public class NewRev {

	public static void main(String[] args) {

					Scanner scn = new Scanner(System.in);
					System.out.println("Enter a number");
					long a = scn.nextLong();

					long reversed = 0;
					while (a != 0) {
						long b = a % 10;
			
						//System.out.println(b);
						reversed = reversed * 10 + b;
						a = a / 10;
					}
					System.out.println(reversed);
				}
			

	}


