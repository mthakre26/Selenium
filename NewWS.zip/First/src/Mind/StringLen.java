package Mind;

public class StringLen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  
	/*	String n = "UFTtesting";
		String z = " QTP/UFT testing";
		String y = " QTP/UFT testing";

		int temp = n.length();
		System.out.println(temp);
		System.out.println(n.charAt(0));
		System.out.println(n.compareTo("Junior QTP/UFT testing"));
		System.out.println(n.concat(" Junior QTP/UFT testing"));
		System.out.println(n.equals(z));
		System.out.println(z.contentEquals(y));
		System.out.println(n.hashCode());
		System.out.println(n.indexOf("UFT"));
		System.out.println(n.intern());
		System.out.println(n.matches("Junior"));
		System.out.println(n.replace(z, n));
		System.out.println(n.substring(5));
		System.out.println(n.trim());
		System.out.println(n);
		System.out.println(n.lastIndexOf(""));
		------------------------------------------------------------
		
		 String str = "kitten";
          int t = 5;
		  int p = str.length();
		  String x = str.substring(0,t) ;
		  String j = str.substring(t+1, p);
		  System.out.println(x+j);
		  if (str.length() <= 1) 
			  System.out.println(str);
		  
		  String x = str.substring(1, str.length()-1);
		  System.out.println(x);
		  
		   last + mid + first
		  System.out.println(str.charAt(str.length()-1) + x + str.charAt(0));
		
		-----------------------------------------------
		int count=0;
		char a[] = n.toCharArray();
		for(char c : a)
		{
		count+=1;
		}
		System.out.println(count);
		 ------------------------------
		  if (str.length() > 3 ) {
			  System.out.println(str);
		  }
		  String copies =str.substring(0,3);
		  for(int h = 0; h< 3; h++){
			 
			  System.out.print(copies); 
		  }
		
		   System.out.println();
		   
		   ----------------------------------*/

		 String str = "kitten";
         int t = 5;
		  int p = str.length();
		//  String x = str.substring(0,t) ;
		//  String j = str.substring(t+1, p);
		 // System.out.println(x+j);
		  if (str.length() <= 1) 
			  System.out.println(str);
		  
		  String x = str.substring(1, str.length()-1);
		  System.out.println(x);
		  
		  // last + mid + first
		  //System.out.println(str.charAt(str.length()-1) + x + str.charAt(0));
		  System.out.println( str.charAt(str.length()-1) + str + str.charAt(str.length()-1));
	}
}
