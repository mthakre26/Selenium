package Mind;

public class ReversePyramid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i = 1; i <= 5; i++) 
		{
            for(int j = 5; j >= i; j--)
            
            {
                System.out.print("*");
            }
                   /* i=1  j=5
            		i=1  j=4
            		i=1  j=3
            		i=1  j=2
            		i=1  j=1 out of inner loop*/
                    
            		/* i=2  j=5
    				i=2 j=4
    				i=2 j=3
    				i=2 j=2 out of inner loop*/
            
            System.out.println("  Out of inner loop");
		}
		
	}

}
