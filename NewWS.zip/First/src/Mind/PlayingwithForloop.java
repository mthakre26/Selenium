package Mind;

public class PlayingwithForloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("************");
		
		for(int star=1; star<= 5; star++ ){
			
			System.out.print("*");
			
			for(int space=0; space<=9; space++){
				
			System.out.print(" ");
			}
			System.out.println("*");
		}
			System.out.print("************");
			
	}

}
