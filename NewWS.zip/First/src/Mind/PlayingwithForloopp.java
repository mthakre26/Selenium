package Mind;

public class PlayingwithForloopp {

	public static void main(String[] args) {
	
	
		// TODO Auto-generated method stub

		line();
		topHalf();
		bottomHalf();
		
		System.out.println(" #===========# ");	
		}
		public static void topHalf() {
			for (int line = 1; line <= 4; line++) {
				System.out.print("|");
				for (int space = 1; space <= (line * -2 + 8); space++) {
				System.out.print(" ");
				}
				System.out.print("<>");
				for (int dot = 1; dot <= (line * 4 - 4); dot++) {
				System.out.print(".");
				}
				System.out.print("<>");
				for (int space = 1; space <= (line * -2 + 8); space++) {
				System.out.print(" ");
				}
				System.out.println("|");}}
		
		public static void bottomHalf() {
			for (int line = 1; line <= 5; line++) {
				System.out.print("|");
				for (int space = 1; space <= line + 1; space++) {
				System.out.print(" ");
				}
				System.out.print("<>");
				for (int dot = line - 4; dot <= 1 ; dot++) {
				System.out.print(".");}
				System.out.print("<>");
				for (int space = line -4; space <=1;space ++) {
				System.out.print(" ");}
				System.out.println("|");}
		}
		
		public static void line() {
		
			System.out.println(" #==================# ");		
		}
	
}

