package Mind;

import java.util.Scanner;

public class SStringg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
		Scanner str = new Scanner(System.in);
		System.out.println("Enter string:");
	    String i = str.nextLine();
		int n=5;
        
		String front = i.substring(0, n);
		
		System.out.println(front);
	}

}
