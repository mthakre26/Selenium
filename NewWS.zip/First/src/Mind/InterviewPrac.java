package Mind;

import java.util.Arrays;

public class InterviewPrac {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str= "better";
		String str1= "ebtter";
		int count = 0;
		
		 /*String NoSpaceStr = str.replaceAll("\\s","d");
		System.out.println(NoSpaceStr);*/
		char a[]= str.toCharArray();
		char b[]= str1.toCharArray();
		
		for(int i=0; i< str.length(); i++){
			
			for(int j = i+1; j<str.length(); j++ ){
				if(a[i] == a[j]){
					System.out.println(a[j]);
			
					count++;
					
				// System.out.print(count);
					break;
				}
				}
			}			
	//	System.out.print(i);
		//System.out.print(count);
		Arrays.sort(a);
		Arrays.sort(b);
		boolean status = true;
		{
		 status = Arrays.equals(a, b);
		}

	if (status){
		System.out.println("anagram");
	}else{
		System.out.println("Not");
	}
	}
}
	

