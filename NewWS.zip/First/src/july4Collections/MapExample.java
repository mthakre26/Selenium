package july4Collections;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

public class MapExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*		
		HashMap<Integer,String> map = new HashMap<>();
		
		map.put(1, "One");
		map.put(2, "Two");
		map.put(3, "Three");
		map.put(4, "One");
		map.put(2, "One");
		System.out.println(map);
		System.out.println(map.get(1));
		
		Set<Integer> keys =  map.keySet(); //Returns Set
		System.out.println(keys);
		System.out.println(map.values());
		//System.out.println(map.remove(1));
		System.out.println(map.toString());*/
		
		
		HashMap<String, ArrayList<String>> listMap = new HashMap<>();
		ArrayList<String> list = new ArrayList<>();
		
		list.add("Pune");
		list.add("Mumbai");
		list.add("Nashik");
		list.add("Aurangabad");
		list.add("Delhi");
		System.out.println(list.size());
		
		listMap.put("Maharashtra", list);
		System.out.println(listMap);
		
		ArrayList<String> list2 = new ArrayList<>();
		list2.add("Datia");
		list2.add("Pachmarhi");
		list2.add("Indore");
		list2.add("chindwada");
		listMap.put("Madhya Pradesh", list2);
		System.out.println(listMap);
		
		for(String key : listMap.keySet()){
			
		System.out.println(listMap.get(key));
		}
		
	}

}
