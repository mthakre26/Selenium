package july4Collections;

import java.util.ArrayList;
import java.util.List;

public class ListExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		ArrayList<String> obj = new ArrayList<>();
		ArrayList<Integer> intList = new ArrayList<>();
		
		obj.add("Pune");
		obj.add("Mumbai");
		obj.add("Chennai");
		obj.add("Delhi");
		obj.add("");
		
		System.out.println(obj);
		
		obj.add("Mumbai");
		obj.add("Delhi");
		System.out.println(obj);
		
		String temp = obj.get(3);
		System.out.println(temp);
		
		obj.remove(1);
		System.out.println(obj);
		obj.remove("Delhi");
		System.out.println(obj);
		
		boolean result = obj.contains("Pune");
		System.out.println(result);
		
		boolean result1 = obj.contains("Bangalore");
		System.out.println(result1);
		
		int index = obj.indexOf("Delhi");
		System.out.println(index);
		
		List<String> newList = obj.subList(0,3);
		System.out.println(newList);
		
		
		for(int i = 0; i< newList.size(); i++){
			System.out.println(newList.get(i));
		}
		
		for (String value : newList){
			System.out.println(value);
		}
	}

}
