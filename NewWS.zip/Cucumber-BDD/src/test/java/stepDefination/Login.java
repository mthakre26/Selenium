package stepDefination;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;


public class Login {

	WebDriver  driver;
	@Given("^User is at login page$")
	public void user_is_at_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.get("http://newtours.demoaut.com");
	}

	@When("^user enters UserName$")
	public void user_enters_UserName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	     driver.findElement(By.name("userName")).sendKeys("Batman");
	}

	@When("^user enters password$")
	public void user_enters_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("password")).sendKeys("batman");
	}
	@When("^user enters UserName\"([^\"]*)\"$")
	public void user_enters_UserName(String arg1) throws Throwable {
		 driver.findElement(By.name("userName")).sendKeys(arg1);
	}

	@When("^user enters password\"([^\"]*)\"$")
	public void user_enters_password(String arg1) throws Throwable {
		driver.findElement(By.name("password")).sendKeys(arg1);
	}

	
	@When("^User clicks login button$")
	public void user_clicks_login_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("login")).click();
	}

	@Then("^login is successful and home page is displayed$")
	public void login_is_successful_and_home_page_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 Assert.assertEquals("Find a Flight: Mercury Tours:", driver.getTitle());
	}
}
