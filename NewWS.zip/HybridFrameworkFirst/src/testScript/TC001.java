package testScript;

import java.util.ArrayList;
import java.util.HashMap;

import library.KeywordLibrary;
import utilities.Excel;

public class TC001 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		HashMap<Integer, ArrayList<String>> map = Excel.getAllData();
		
		for (Integer key : map.keySet()) {
			ArrayList<String> list = map.get(key);
			KeywordLibrary.controller(list.get(0), list.get(1), list.get(2), list.get(3), list.get(4), list.get(5));
			
		}
	}

}
