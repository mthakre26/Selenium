package library;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class KeywordLibrary {
	static WebDriver driver;
	
	public static void controller(String methodName,String arg1, String arg2, String arg3, String arg4, String arg5) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Method method = KeywordLibrary.class.getDeclaredMethod(methodName, String.class, String.class,String.class, String.class,String.class);
		method.invoke(KeywordLibrary.class, arg1, arg2, arg3, arg4, arg5);
	}
	
	public static void launchBrowser(String arg1, String arg2, String arg3, String arg4, String arg5) {
		if(arg1.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
			driver = new ChromeDriver();
		} else if (arg1.equals("firefox")) {
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\M1038750\\Downloads\\firefox_win32\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		
		driver.get(arg2);
	}
	public static void enterText(String arg1, String arg2, String arg3, String arg4, String arg5) {
		if(arg1.equals("name")) {
			driver.findElement(By.name(arg2)).sendKeys(arg3);
		} else if(arg1.equals("id")) {
			driver.findElement(By.id(arg2)).sendKeys(arg3);
		} else if(arg1.equals("xpath")) {
			driver.findElement(By.xpath(arg2)).sendKeys(arg3);
		}
		
	}
	
	public static void clickButton(String arg1, String arg2, String arg3, String arg4, String arg5) {
		if(arg1.equals("name")) {
			driver.findElement(By.name(arg2)).click();
		} else if(arg1.equals("id")) {
			driver.findElement(By.id(arg2)).click();
		} else if(arg1.equals("xpath")) {
			driver.findElement(By.xpath(arg2)).click();
		}
	}		
	public static void clickRadio(String arg1, String arg2, String arg3, String arg4, String arg5) {
			if(arg1.equals("name")) {
				driver.findElement(By.name(arg2)).click();
			} else if(arg1.equals("id")) {
				driver.findElement(By.id(arg2)).click();
			} else if(arg1.equals("xpath")) {
				driver.findElement(By.xpath(arg2)).click();
			}
		}
		
	public static void selectFromDopDown(String arg1, String arg2, String arg3, String arg4, String arg5) {
			WebElement dropDown = null;
			if(arg1.equals("name")) {
				dropDown = driver.findElement(By.name(arg2));
			} else if(arg1.equals("id")) {
				dropDown = driver.findElement(By.id(arg2));
			} else if(arg1.equals("xpath")) {
				dropDown = driver.findElement(By.xpath(arg2));
			}
			
			Select dd = new Select(dropDown);
			dd.selectByVisibleText(arg3);
	}

	/*public static void clickRadio2(String arg1, String arg2, String arg3, String arg4, String arg5) {
	if(arg1.equals("name")) {
		driver.findElement(By.name(arg2)).click();
	} else if(arg1.equals("id")) {
		driver.findElement(By.id(arg2)).click();
	} else if(arg1.equals("xpath")) {
		driver.findElement(By.xpath(arg2)).click();
	}
}*/
	public static void selectAirlineDopDown(String arg1, String arg2, String arg3, String arg4, String arg5) {
		WebElement dropDown1 = null;
		if(arg1.equals("name")) {
			dropDown1 = driver.findElement(By.name(arg2));
		} else if(arg1.equals("id")) {
			dropDown1 = driver.findElement(By.id(arg2));
		} else if(arg1.equals("xpath")) {
			dropDown1 = driver.findElement(By.xpath(arg2));
		}
		
		Select dd = new Select(dropDown1);
		dd.selectByVisibleText(arg3);
	}
	
	/*public static void clickButton1(String arg1, String arg2, String arg3, String arg4, String arg5) {
	if(arg1.equals("name")) {
		driver.findElement(By.name(arg2)).click();
	} else if(arg1.equals("id")) {
		driver.findElement(By.id(arg2)).click();
	} else if(arg1.equals("xpath")) {
		driver.findElement(By.xpath(arg2)).click();
	}
	}	*/

	public static void clickRadioforFlightselection(String arg1, String arg2, String arg3, String arg4, String arg5) {
	 
	 List<WebElement>  rows= driver.findElements(By.xpath(arg2));
	 
	 for(WebElement row: rows){
			
			List<WebElement> cells = row.findElements(By.tagName(arg4));
			
			for(int i = 0; i < cells.size(); i++){
				
				if(cells.get(i).getText().equals(arg5)){
					
					cells.get(i-1).click();
				}				
			}			
	 	}
	}
	
	/*public static void clickRadio4(String arg1, String arg2, String arg3, String arg4, String arg5) {
		 
		 List<WebElement>  rows= driver.findElements(By.xpath(arg2));
		 
		 for(WebElement row: rows){
				
				List<WebElement> cells = row.findElements(By.tagName(arg4));
				
				for(int i = 0; i < cells.size(); i++){
					
					if(cells.get(i).getText().equals(arg5)){
						
						cells.get(i-1).click();
					}				
				}			
		 	}
		}	*/
	
	
}

