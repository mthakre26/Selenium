package advSel_sept08;

public class TestReflectionn {

	
	String name;
	String color;
	int year;
	
	public static void method(){
		System.out.println(" Simple_Method");
	}
	public void method1(int value){
		System.out.println("Method 1 and value is : " + value);
	}
	public static void method2(String val){
		System.out.println("Method2 and value is : " + val);
	}
	
}
