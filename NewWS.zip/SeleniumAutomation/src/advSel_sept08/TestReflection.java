package advSel_sept08;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class TestReflection {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		// TODO Auto-generated method stub

		TestReflectionn tr = new TestReflectionn();
		
		Class cls = tr.getClass();
		System.out.println(cls);
		Method[] methods = cls.getDeclaredMethods();
		System.out.println(methods);
		for (Method method : methods) {
			System.out.println(method.getName());
		}
		Field[] fields = cls.getDeclaredFields();
		System.out.println(fields);
		for (Field field : fields) {
			System.out.println(field.getName());
		} 
	    Method method = cls.getDeclaredMethod("method1",int.class);
	    method.setAccessible(true);
        method.invoke(tr,20);
        
        Method met = TestReflectionn.class.getDeclaredMethod("method2", String.class);
        met.setAccessible(true);
        met.invoke(TestReflectionn.class,"Mumbai");
        
        
	}

}
