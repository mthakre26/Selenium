package aug24Alerts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class TableEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver  driver = new ChromeDriver();
		
		driver.get("https://www.toolsqa.com/automation-practice-table/");
		
		String x = driver.findElement(By.xpath("//table[@class='tsc_table_s13']/tbody/tr[2]/td")).getText();
		System.out.println(x);
		String x1 = driver.findElement(By.xpath("//table[@class='tsc_table_s13']/tbody/tr[3]/td[3]")).getText();
		System.out.println(x1);
		String x2 = driver.findElement(By.xpath("//table[@class='tsc_table_s13']/tfoot/tr/td")).getText();
		System.out.println(x2);
		
		/*
		String alldata = driver.findElement(By.xpath("//table[@class='tsc_table_s13']")).getText();
		System.out.println(alldata);
		
		String alldatabody = driver.findElement(By.xpath("//table[@class='tsc_table_s13']/tbody")).getText();
		System.out.println(alldatabody);*/
		  
		List<WebElement> rows = driver.findElements(By.xpath("//table[@class='tsc_table_s13']/tbody/tr"));
		
		for (WebElement row : rows){
			
			List<WebElement> cells = row.findElements(By.tagName("td"));
			
			for(WebElement cell : cells){
				
				System.out.println(cell.getText()+" ");
				
			}
			System.out.println();
		}
		
	}

}
 