package aug24Alerts;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertsBasic {

	public static void main(String[] args) throws Throwable {
		// TODO Auto-generated method stub

		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver  driver = new ChromeDriver();
		
		driver.get("https://www.seleniumeasy.com/test/javascript-alert-box-demo.html");
		
		driver.findElement(By.xpath("//button[contains(text(),'Click me!')]")).click();
		
		Alert alert = driver.switchTo().alert();
		
		String text = alert.getText();
		System.out.println(text);
        Thread.sleep(3000);
        alert.dismiss();
        
        driver.findElement(By.xpath("//button[@class = 'btn btn-default btn-lg']")).click();
		
		String text1 = alert.getText();
		System.out.println(text1);
        Thread.sleep(3000);
        alert.dismiss();
        
        driver.findElement(By.xpath("//button[contains(text(),'Click for Prompt Box')]")).click();
		
		String text2 = alert.getText();
		System.out.println(text2);
		alert.sendKeys("Input for Alert ");
        Thread.sleep(3000);
        alert.accept();      
        
	}

}
