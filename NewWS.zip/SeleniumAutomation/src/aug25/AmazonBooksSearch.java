package aug25;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonBooksSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		WebDriver  driver = new ChromeDriver();
		
		driver.get("https://www.amazon.in/s?k=books&ref=nb_sb_noss_2");
		/*driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("books");
		driver.findElement(By.xpath("//input[@id='nav-input']")).click();*/
		List<WebElement> x = driver.findElements(By.xpath("//span[@class='a-size-medium a-color-base a-text-normal']"));
		System.out.println(x.size());
		
		List<WebElement> price = driver.findElements(By.xpath("//span[@class='a-price-whole']"));
		System.out.println(price);
		
		for(int i=0; i<= x.size()-1;i++){
		System.out.println(x.get(i).getText());
		  
		/*if(x.get(i).getText().equals("Think and Grow Rich"))
				{
			x.get(i+1).click();
		}*/
		for(int j=0; j<=i;j++){
			
			System.out.println(price.get(j).getText());
		}

		System.out.println();
	}
}
}
