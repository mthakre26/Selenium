package sept07;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PageScrol {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver  driver = new ChromeDriver();
		
		driver.get("https://demoqa.com/autocomplete/");
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0, 250)");
		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0, 250)");
		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0, 250)");
		Thread.sleep(2000);
	}
 
}
