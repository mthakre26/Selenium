package sept07;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class RightClick {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32\\InternetExplorer.exe");
		WebDriver  driver = new InternetExplorerDriver();
		
		driver.get("http://newtours.demoaut.com/");
		
        WebElement link = driver.findElement(By.linkText("REGISTER"));
		
        
	}

}
