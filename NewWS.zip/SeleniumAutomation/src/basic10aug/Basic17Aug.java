package basic10aug;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Basic17Aug {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		WebDriver  driver = new ChromeDriver();
		
		driver.get("http://newtours.demoaut.com/");
		driver.manage().window().maximize();
		System.out.println(driver.getTitle());
		System.out.println(driver.getCurrentUrl());
		
		driver.findElement(By.name("userName")).sendKeys("Batman");
		driver.findElement(By.name("password")).sendKeys("batman");
	//	driver.findElement(By.name("login")).click();
		
		driver.findElement(By.linkText("REGISTER")).click();
		
		WebElement dropDown = driver.findElement(By.name("country"));
		
		Select s= new Select(dropDown);
		
		//s.selectByValue("251");
		//s.selectByIndex(3);
		//s.selectByVisibleText("UNITED STATES");
		Select multi = new Select(driver.findElement(By.id("selenium_commands")));
		multi.selectByIndex(0);
		multi.selectByVisibleText("Wait Commands");
		multi.deselectByIndex(5);
	
		multi.deselectAll();
		//driver.close();
	}

}
