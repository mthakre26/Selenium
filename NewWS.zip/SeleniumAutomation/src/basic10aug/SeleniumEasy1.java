package basic10aug;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumEasy1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver  driver = new ChromeDriver();
		
		driver.get("https://www.seleniumeasy.com/test/jquery-dropdown-search-demo.html");
		//single select dropdown
		driver.findElement(By.xpath("//span[@class='select2-selection__arrow']")).click();
		driver.findElement(By.xpath("//ul[@id='select2-country-results']/li[3]")).click();
		//Multi select need to repeat the code just value after slash will change
		driver.findElement(By.xpath("//input[@class='select2-search__field']")).click();
		WebElement dd=driver.findElement(By.xpath("//ul[@id='select2-btuu-results']/li[1]"));
		dd.click();
	}

}
