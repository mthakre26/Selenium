package basic10aug;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class PracticeXpathTour {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://newtours.demoaut.com");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//input[@name='userName']")).sendKeys("Batman");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("batman");
		driver.findElement(By.xpath("//input[@name='login']")).click();;
		
		driver.findElement(By.xpath("//input[@value='oneway']")).click();
		
		WebElement dropdowns = driver.findElement(By.name("passCount"));
		dropdowns.click();
		Select s = new Select(dropdowns);
		s.selectByValue("3");
		
		WebElement dropdowns1 = driver.findElement(By.name("fromPort"));
		dropdowns1.click();
		Select a = new Select(dropdowns1);
		a.selectByValue("Portland");
		
		WebElement dropdowns2 = driver.findElement(By.name("fromMonth"));
		dropdowns2.click();
		Select b = new Select(dropdowns2);
		b.selectByValue("12");
	
		WebElement dropdowns3 = driver.findElement(By.name("fromDay"));
		dropdowns3.click();
		Select c = new Select(dropdowns3);
		c.selectByValue("2");
		
		WebElement dropdowns4 = driver.findElement(By.name("toPort"));
		dropdowns4.click();
		Select d = new Select(dropdowns4);
		d.selectByValue("London");
		
		WebElement dropdowns5 = driver.findElement(By.name("toMonth"));
		dropdowns5.click();
		Select e = new Select(dropdowns5);
		e.selectByValue("4");
		
		WebElement dropdowns6 = driver.findElement(By.name("toDay"));
		dropdowns6.click();
		Select f = new Select(dropdowns6);
		f.selectByValue("23");
		
		driver.findElement(By.xpath("//input[@value ='First']")).click();
		
		WebElement dropdowns8 = driver.findElement(By.name("airline"));
		dropdowns8.click();
		Select h = new Select(dropdowns8);
		h.selectByVisibleText("Pangea Airlines");
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//input[@name='findFlights']")).click();
		
		driver.findElement(By.xpath("//input[@value='Unified Airlines$563$125$11:24']")).click();
		
		driver.findElement(By.xpath("//input[@value='Blue Skies Airlines$651$99$14:30']")).click();
		
		
		driver.findElement(By.xpath("//input[@name='reserveFlights']")).click();
		
		driver.findElement(By.xpath("//input[@name='passFirst0']")).sendKeys("Ram");
		driver.findElement(By.xpath("//input[@name='passLast0']")).sendKeys("Sham");
		
		driver.findElement(By.xpath("//input[@name='passFirst1']")).sendKeys("Ram");
		driver.findElement(By.xpath("//input[@name='passLast1']")).sendKeys("Sham");
		
		driver.findElement(By.xpath("//input[@name='passFirst2']")).sendKeys("Ram");
		driver.findElement(By.xpath("//input[@name='passLast2']")).sendKeys("Sham");

		WebElement dropdowns10 = driver.findElement(By.name("pass.0.meal"));
		dropdowns10.click();
		Select j = new Select(dropdowns10);
		j.selectByVisibleText("Bland");
		
		List<WebElement> x= driver.findElements(By.xpath("//input[@name='ticketLess']"));
        System.out.println(x.size());
                for(int i=0;i<=x.size()-1;i++)
                {
                	
                    x.get(i).click();
                    break;
                }
		driver.findElement(By.xpath("//input[@name='buyFlights']")).click();
		
	}
	

}
