package Utility;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.sun.rowset.internal.Row;

public class Excel {

	public static HashMap<Integer, ArrayList<String>> getalldata() throws Exception{
		
		File file = new File("C:\\Users\\M1038750\\workspace\\FlipKart_Hybrid\\src\\TestData\\InputData1.xls");
        FileInputStream input = new FileInputStream(file);
		HSSFWorkbook workbook = new HSSFWorkbook(input);
		HSSFSheet sheet = workbook.getSheet("sheet3");
		
		int maxrows = sheet.getLastRowNum();
		System.out.println(maxrows);
		
		HashMap<Integer, ArrayList<String>> map = new HashMap<>();
		
		for (int i=0 ; i <= maxrows; i++){
			ArrayList<String> list = new ArrayList<>();
			HSSFRow row = sheet.getRow(i);
			int lastCell =  row.getLastCellNum();
			
			for(int j=0; j<lastCell; j++){
				
				HSSFCell cell = row.getCell(j);
				list.add(cell.getStringCellValue());
			}
			map.put(i, list);
		}
	 return map;
	}
	
}
