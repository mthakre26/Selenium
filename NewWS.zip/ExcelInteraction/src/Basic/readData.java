package Basic;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class readData {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		
		File file = new File ("C:\\Users\\M1038750\\Desktop\\Data_Test.xls");
		
		FileInputStream input = new FileInputStream(file);
		
		HSSFWorkbook workbook = new HSSFWorkbook(input);
		HSSFSheet sheet = workbook.getSheet("Sheet1");
		
		HSSFRow row = sheet.getRow(2);
		HSSFCell cell = row.getCell(3);
		
		String data = cell.getStringCellValue();
		
		System.out.println(data);
	}

}
