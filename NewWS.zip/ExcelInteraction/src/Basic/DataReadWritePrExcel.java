package Basic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFShapeFactory;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class DataReadWritePrExcel {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		File file = new File("C:\\Users\\M1038750\\workspace\\ExcelInteraction\\data.xls");
		FileInputStream input= new FileInputStream(file);
		
		
		
		HSSFWorkbook workbook = new HSSFWorkbook(input);
		HSSFSheet sheet = workbook.getSheet("Sheet1");
		HSSFRow row = sheet.getRow(1);
		HSSFCell cell= row.getCell(2);
		String cellval = cell.getStringCellValue();
		System.out.println(cellval);	
		HSSFRow roww = sheet.createRow(3);
		HSSFCell cellw = roww.createCell(3);
		cellw.setCellValue("dataaa");
		FileOutputStream out = new FileOutputStream(file);
		workbook.write(out);
		out.close();
		
	}

}
