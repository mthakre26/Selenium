package Basic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonExcelEx {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\M1038750\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver  driver = new ChromeDriver();
		
		driver.get("https://www.amazon.in/s?k=books&ref=nb_sb_noss_2");
		
		List<WebElement> books = driver.findElements(By.xpath("//*[@class='sg-col-20-of-24 s-result-item sg-col-0-of-12 sg-col-28-of-32 sg-col-16-of-20 sg-col sg-col-32-of-36 sg-col-12-of-16 sg-col-24-of-28']"));
		System.out.println(books);
		
	    for (WebElement book : books) {
	    	
	    	String bookname = book.findElement(By.xpath(".//*[@class='a-size-mini a-spacing-none a-color-base s-line-clamp-2']")).getText();
	    	System.out.println(bookname);

	    	String price = book.findElement(By.xpath(".//*[@class='a-price-whole']")).getText();
	    	System.out.println(price);
	    	
	}
	   
}

}
